package com.example.dairyservices.Prevalent;

import com.example.dairyservices.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser=new Users();

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}

